
using td12.Models;
using System.Collections.Generic;
using System.Linq;

namespace td12.Services
{
    public class CustomersRepository : ICustomersRepository
    {
        private readonly webapidbContext context;

        public CustomersRepository(webapidbContext context)
        {
            this.context = context;
        }

        public bool DeleteCustomers(int id)
        {
            var customer =this.context.Find<TblCustomer>(id);
            if(customer != null){
                this.context.Remove<TblCustomer>(customer);
                this.context.SaveChanges();
                return true;
            }
            return false;
        }

        public List<TblCustomer> GetCustomers()
        {
            return this.context.TblCustomers.ToList();
        }

        public TblCustomer InsertCustomer(TblCustomer customer)
        {
              var newCustomer = this.context.Add<TblCustomer>(customer).Entity;
                this.context.SaveChanges();
                return newCustomer;
            // return this.context.TblCustomers.OrderByDescending(c => c.CustomerId).FirstOrDefault();
        }

        public TblCustomer UpdateCustomer(TblCustomer customer)
        {
            var oldCustomer = this.context.Find<TblCustomer>(customer.CustomerId);
            if(oldCustomer != null){
                oldCustomer.CustomerName = (customer.CustomerName == null) ? oldCustomer.CustomerName : customer.CustomerName;
                oldCustomer.City = (customer.City == null) ? oldCustomer.City : customer.City;
                oldCustomer.CreationDate = (customer.CreationDate == null) ? oldCustomer.CreationDate : customer.CreationDate;
                this.context.Update<TblCustomer>(oldCustomer);
                this.context.SaveChanges();
            }
            return  oldCustomer;
             //this.context.TblCustomers.Where(c => c.CustomerId == customer.CustomerId).FirstOrDefault();
        }
    }
}