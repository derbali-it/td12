﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using td12.Services;
using td12.Models;
namespace td12.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomersController : ControllerBase
    {
        private readonly ICustomersRepository repository;

        public CustomersController(ICustomersRepository repository)
        {
            this.repository = repository;
        }
        
        [HttpGet]
        public IActionResult getCustomers(){
           return Ok(repository.GetCustomers());
        }

       [HttpDelete("{id}")]
        public IActionResult deleteCustomer(int id){
            var deleted = this.repository.DeleteCustomers(id);
            if(deleted)
                return Ok("Customer deleted");
            return BadRequest("Attention! Customer with id "+ id +" not found");
        }

        [HttpPost]
        public IActionResult addCustomer([FromBody] TblCustomer customer){
            var result = this.repository.InsertCustomer(customer);
            if(result != null)
                return Ok(customer);
            return BadRequest("Attention! check data of your Customer");
        }

        [HttpPatch]
        public IActionResult updateCustomer([FromBody] TblCustomer customer){
            var result = this.repository.UpdateCustomer(customer);
            if(result != null)
                return Ok(result);
            return BadRequest("Attention! check data of your Customer");
        }
    }
}
